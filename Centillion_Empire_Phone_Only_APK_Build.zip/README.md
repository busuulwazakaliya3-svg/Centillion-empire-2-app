# Centillion Empire — Hybrid App (phone-only APK build enabled)

This project contains the existing 13-section Centillion Empire portal, PWA app-shell support, and Capacitor Android configuration.

## Build an Android APK using a phone
See `PHONE-ONLY-APK-GUIDE.txt`. The included GitHub Actions workflow (`.github/workflows/build-apk.yml`) builds a test/debug APK in the cloud and uploads it as a downloadable workflow artifact.

## Web/PWA deployment
Upload the contents of `www/` to a static HTTPS host to publish the browser-installable version.

## Important production limitation
The portal currently stores records in each visitor's browser using `localStorage`. It does not yet provide a shared member database, cross-device accounts, secure authentication, or automatic application email delivery to `centillionempire@gmail.com`. Add and test a secure backend before using it to collect real member information.
