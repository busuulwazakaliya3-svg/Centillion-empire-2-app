CENTILLION EMPIRE — ANDROID APK BUILD PACKAGE

This archive contains the 13 existing Centillion Empire portal pages packaged as a Capacitor hybrid app. The dashboard is the app start page.

PHONE-ONLY GITHUB BUILD
1. Upload this ZIP file to the root of your GitHub repository. The ZIP must be named exactly:
   Centillion_Empire_Phone_Only_APK_Build.zip
2. In the repository, create a new file with this exact path:
   .github/workflows/build-apk.yml
3. Paste the workflow YAML provided in BUILD_WORKFLOW_INSTRUCTIONS.txt into that file and commit it.
4. Open the repository Actions tab. Select “Build Centillion Empire APK” and run it, or wait for the push-triggered build.
5. When complete, open the successful workflow run and download the artifact named centillion-empire-debug-apk. Extract it to find app-debug.apk.

IMPORTANT LIMITATIONS
- This build produces a debug APK for testing and direct sharing. It is not a Play Store signed release.
- Existing portal pages use browser localStorage. Data is stored separately on each device. A shared backend, authentication, and live Gmail application delivery must be configured before using this as a real multi-member production system.
- Do not collect sensitive identity or financial information in this demo build.
